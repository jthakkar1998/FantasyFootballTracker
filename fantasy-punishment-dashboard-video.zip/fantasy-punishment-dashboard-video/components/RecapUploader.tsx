"use client";

import { FormEvent, useMemo, useState } from "react";
import { createClient } from "@supabase/supabase-js";

const MAX_BYTES = 45 * 1024 * 1024;

export function RecapUploader({ token }: { token: string }) {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<"idle" | "uploading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  const supabase = useMemo(() => {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
    return url && key ? createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } }) : null;
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!file) return;
    if (!supabase) {
      setStatus("error");
      setMessage("Video uploads are not configured yet.");
      return;
    }
    if (file.size > MAX_BYTES) {
      setStatus("error");
      setMessage("Please choose a video that is 45 MB or smaller.");
      return;
    }

    setStatus("uploading");
    setMessage("Preparing secure upload…");

    try {
      const intentResponse = await fetch("/api/recap/upload-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, contentType: file.type, size: file.size })
      });
      const intent = await intentResponse.json();
      if (!intentResponse.ok) throw new Error(intent.error ?? "Could not prepare upload.");

      setMessage("Uploading video… keep this page open.");
      const { error: uploadError } = await supabase.storage
        .from("recap-videos")
        .uploadToSignedUrl(intent.path, intent.token, file, { contentType: file.type });
      if (uploadError) throw uploadError;

      setMessage("Saving recap…");
      const finalizeResponse = await fetch("/api/recap/finalize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token,
          path: intent.path,
          originalFilename: file.name,
          size: file.size,
          contentType: file.type
        })
      });
      const finalized = await finalizeResponse.json();
      if (!finalizeResponse.ok) throw new Error(finalized.error ?? "Could not finish upload.");

      setStatus("success");
      setMessage("Recap submitted. Your obligation has been marked complete.");
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Upload failed. Please try again.");
    }
  }

  if (status === "success") {
    return (
      <div className="upload-success">
        <span className="eyebrow">SUBMITTED</span>
        <h2>Recap received.</h2>
        <p>{message}</p>
        <a className="button primary inline-button" href="/recaps">View the recap archive</a>
      </div>
    );
  }

  return (
    <form className="upload-form" onSubmit={submit}>
      <label>
        Recap video
        <input
          type="file"
          accept="video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm"
          required
          disabled={status === "uploading"}
          onChange={(event) => {
            setFile(event.target.files?.[0] ?? null);
            setStatus("idle");
            setMessage("");
          }}
        />
      </label>
      <p className="helper-text">MP4, MOV, or WebM · maximum 45 MB</p>
      {file ? <p className="selected-file">Selected: {file.name} · {(file.size / 1024 / 1024).toFixed(1)} MB</p> : null}
      {message ? <div className={`notice ${status === "error" ? "error" : "success"}`}>{message}</div> : null}
      <button className="button primary" type="submit" disabled={!file || status === "uploading"}>
        {status === "uploading" ? "Uploading…" : "Upload recap"}
      </button>
    </form>
  );
}
